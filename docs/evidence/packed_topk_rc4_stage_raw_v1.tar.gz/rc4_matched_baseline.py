import hashlib
import json
import resource
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path('/home/riomus/sfora-rc4-profile-ac422258')
LIBRARY = Path('/home/riomus/sfora-cutile-e67a5d1-target/release/libsfora_cutile_int8_score.so')
INPUTS = ROOT / 'evidence-inputs'
OUTPUTS = ROOT / 'evidence-outputs'
sys.path.insert(0, '/home/riomus/sfora-release-gate-1e6268b549a42d849b0ea85276dd1aad128c84ef/src')
from sfora.cutile_int8 import CutilePackedInt8Gallery

library_sha256 = hashlib.sha256(LIBRARY.read_bytes()).hexdigest()
assert library_sha256 == 'a9e583881201760088f3d99c180367e587ca68219c79dfe1760a3467f06b8dea'
rows = 1_000_000
gallery_codes = np.fromfile(INPUTS / f'gallery_{rows}_codes.bin', dtype=np.int8).reshape(rows, 128)
gallery_norms = np.fromfile(INPUTS / f'gallery_{rows}_norms.bin', dtype='<f2')
with CutilePackedInt8Gallery.open(LIBRARY, gallery_codes, gallery_norms) as gallery:
    for batch in (1, 32):
        query_codes = np.fromfile(INPUTS / f'query_{batch}_codes.bin', dtype=np.int8).reshape(batch, 128)
        query_norms = np.fromfile(INPUTS / f'query_{batch}_norms.bin', dtype='<f2')
        started = time.perf_counter_ns()
        ordinals, scores = gallery.search(query_codes, query_norms, k=10)
        first_call_ns = time.perf_counter_ns() - started
        fused = json.loads((OUTPUTS / f'fused_{batch}.json').read_text().splitlines()[0])
        assert ordinals.reshape(-1).tolist() == fused['ordinals']
        assert scores.reshape(-1).view('<u4').tolist() == fused['score_bits']
        for _ in range(5):
            gallery.search(query_codes, query_norms, k=10)
        samples = []
        for _ in range(50):
            started = time.perf_counter_ns()
            gallery.search(query_codes, query_norms, k=10)
            samples.append(time.perf_counter_ns() - started)
        report = {
            'schema': 'sfora-rc4-matched-rc3-baseline-v1',
            'batch': batch,
            'gallery_rows': rows,
            'scorer_library_sha256': library_sha256,
            'first_call_ns': first_call_ns,
            'warmups': 5,
            'raw_end_to_end_ns': samples,
            'exact_score_bits': True,
            'exact_ordinals': True,
            'process_peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        }
        destination = OUTPUTS / f'rc3_library_{batch}.json'
        with destination.open('x') as stream:
            json.dump(report, stream, sort_keys=True)
            stream.write('\n')
        ordered = sorted(samples)
        print(batch, ordered[24], ordered[47], ordered[49], flush=True)
