import hashlib
import json
import sqlite3
import statistics
from pathlib import Path

ROOT = Path('/home/riomus/sfora-rc4-profile-ac422258')
INPUTS = ROOT / 'evidence-inputs'
OUTPUTS = ROOT / 'evidence-outputs'
LIBRARY = Path('/home/riomus/sfora-cutile-e67a5d1-target/release/libsfora_cutile_int8_score.so')
BINARY = ROOT / 'target/release/rc4_profile'
SOURCE_COMMIT = 'f04ff31fc68eef2c3df58833ed1fc490774f5aba'
BASELINE_RECEIPT = '88e6874c93ca4f33e8856f823e82319d93773413dc9ca19630ac00674e73e42d'
CALLS = 56

def sha(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

def sha_concat(*paths):
    digest = hashlib.sha256()
    for path in paths:
        with open(path, 'rb') as stream:
            for block in iter(lambda: stream.read(1 << 20), b''):
                digest.update(block)
    return digest.hexdigest()

def first_json(path):
    with open(path) as stream:
        return json.loads(stream.readline())

def kernel_means(mode, batch):
    db = sqlite3.connect(OUTPUTS / f'{mode}_{batch}_profile.sqlite')
    names = dict(db.execute('select id,value from StringIds'))
    totals = {}
    counts = {}
    for name, count, elapsed in db.execute('select shortName,count(*),sum(end-start) from CUPTI_ACTIVITY_KIND_KERNEL group by shortName'):
        label = names[name]
        totals[label] = elapsed
        counts[label] = count
    for name in totals:
        assert counts[name] % CALLS == 0, (mode, batch, name, counts[name])
    return {name: round(elapsed / CALLS) for name, elapsed in totals.items()}, db

def peak_cuda_pool(mode, batch):
    db = sqlite3.connect(OUTPUTS / f'mem_{mode}_{batch}_profile.sqlite')
    result = db.execute('select max(localMemoryPoolUtilizedSize) from CUDA_GPU_MEMORY_USAGE_EVENTS').fetchone()[0]
    assert isinstance(result, int) and result > 0
    return result

def rank(samples, percentage):
    ordered = sorted(samples)
    return ordered[(len(ordered) * percentage + 99) // 100 - 1]

artifacts = {}
for path in sorted(OUTPUTS.iterdir()):
    if path.suffix in {'.json', '.nsys-rep'}:
        artifacts[path.name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
artifacts['evidence-inputs/manifest.json'] = {'bytes': (INPUTS / 'manifest.json').stat().st_size, 'sha256': sha(INPUTS / 'manifest.json')}
artifacts['rc4_matched_baseline.py'] = {'bytes': (ROOT / 'rc4_matched_baseline.py').stat().st_size, 'sha256': sha(ROOT / 'rc4_matched_baseline.py')}
rows = {}
fused_rows = {}
for batch in (1, 32):
    tag = str(batch)
    exact = [first_json(OUTPUTS / f'exact_{size}_{batch}.json') for size in (1_000_000, 1_000_003)]
    assert all(item['exact_ordinals'] and item['exact_score_bits'] for item in exact)
    split = first_json(OUTPUTS / f'split_{batch}.json')
    fused = first_json(OUTPUTS / f'fused_{batch}.json')
    rc3 = first_json(OUTPUTS / f'rc3_library_{batch}.json')
    assert len(split['raw_end_to_end_ns']) == len(fused['raw_end_to_end_ns']) == len(rc3['raw_end_to_end_ns']) == 50
    assert fused['ordinals'] == rc3.get('ordinals', fused['ordinals'])
    split_kernels, split_db = kernel_means('split', batch)
    fused_kernels, _ = kernel_means('fused', batch)
    assert split_kernels.keys() == {'score_tile_for_profile_entry', 'select_tile_for_profile_entry', 'merge_topk_entry', 'full_entry'}
    assert fused_kernels.keys() == {'score_block_topk_entry', 'merge_topk_entry', 'full_entry'}
    h2d = round(split_db.execute('select sum(end-start) from CUPTI_ACTIVITY_KIND_MEMCPY where copyKind=1 and bytes<10000').fetchone()[0] / CALLS)
    d2h = round(split_db.execute('select sum(end-start) from CUPTI_ACTIVITY_KIND_MEMCPY where copyKind=2').fetchone()[0] / CALLS)
    stages = {
        'host_to_device': h2d,
        'score': split_kernels['score_tile_for_profile_entry'],
        'block_selection': split_kernels['select_tile_for_profile_entry'],
        'merge': split_kernels['merge_topk_entry'],
        'buffer_initialization': split_kernels['full_entry'],
        'device_to_host': d2h,
    }
    stages['host_and_api'] = round(statistics.mean(split['raw_end_to_end_ns']) - sum(stages.values()))
    assert all(value > 0 for value in stages.values()), stages
    row = {
        'exact_score_bits': True,
        'exact_ordinals': True,
        'tail_1000003_exact': True,
        'end_to_end_ns': split['raw_end_to_end_ns'],
        'stage_mean_ns': stages,
        'gpu_peak_memory_bytes': peak_cuda_pool('split', batch),
        'process_peak_rss_bytes': split['process_peak_rss_bytes'],
        'compile_first_call_ns': split['first_call_ns'],
        'matched_rc3': {
            'end_to_end_ns': rc3['raw_end_to_end_ns'],
            'p50_ns': rank(rc3['raw_end_to_end_ns'], 50),
            'p95_ns': rank(rc3['raw_end_to_end_ns'], 95),
            'p99_ns': rank(rc3['raw_end_to_end_ns'], 99),
            'process_peak_rss_bytes': rc3['process_peak_rss_bytes'],
            'first_call_ns': rc3['first_call_ns'],
        },
        'fused_diagnostic': {
            'end_to_end_ns': fused['raw_end_to_end_ns'],
            'stage_mean_ns': fused_kernels,
            'gpu_peak_memory_bytes': peak_cuda_pool('fused', batch),
            'process_peak_rss_bytes': fused['process_peak_rss_bytes'],
            'compile_first_call_ns': fused['first_call_ns'],
        },
    }
    rows[tag] = row
    fused_rows[tag] = fused_kernels
receipt = {
    'schema': 'sfora-packed-topk-rc4-stage-v1',
    'source_commit': SOURCE_COMMIT,
    'gallery_sha256': sha_concat(INPUTS / 'gallery_1000000_codes.bin', INPUTS / 'gallery_1000000_norms.bin'),
    'query_sha256': {str(batch): sha_concat(INPUTS / f'query_{batch}_codes.bin', INPUTS / f'query_{batch}_norms.bin') for batch in (1,32)},
    'baseline_receipt_sha256': BASELINE_RECEIPT,
    'diagnostic_binary_sha256': sha(BINARY),
    'rc3_library_sha256': sha(LIBRARY),
    'fixture_manifest_sha256': sha(INPUTS / 'manifest.json'),
    'profiler_report_sha256': {str(batch): sha(OUTPUTS / f'split_{batch}_profile.nsys-rep') for batch in (1,32)},
    'gallery_rows': 1_000_000,
    'dimensions': 128,
    'top_k': 10,
    'warmups': 5,
    'samples': 50,
    'traced_calls': CALLS,
    'device': 'NVIDIA GB10',
    'profiler': 'NVIDIA Nsight Systems 2025.3.2',
    'tileiras': 'NVIDIA CUDA TileIR 13.4.92',
    'gpu_peak_scope': 'maximum CUDA memory-pool utilized bytes in a separate memory-enabled trace',
    'host_and_api_scope': 'residual of 50-sample mean end-to-end latency minus 56-call mean GPU kernel and query-transfer times; estimate, not a direct per-call host trace',
    'h2d_scope': 'per-request query code and norm copies; excludes one-time gallery admission',
    'batches': rows,
    'artifact_hashes': artifacts,
}
path = OUTPUTS / 'packed_topk_rc4_stage_v1.json'
with path.open('x') as stream:
    json.dump(receipt, stream, indent=2, sort_keys=True)
    stream.write('\n')
for batch in (1,32):
    row=rows[str(batch)]
    print(batch, 'split p99', rank(row['end_to_end_ns'],99), 'rc3 p99',row['matched_rc3']['p99_ns'], 'stages',row['stage_mean_ns'])
print('receipt_sha256',sha(path))
